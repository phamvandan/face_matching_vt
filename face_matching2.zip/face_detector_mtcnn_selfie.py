'''
Uses weights and models implementation' from
https://github.com/deepinsight/insightface
'''

import imutils
import os
import cv2
from os import path, listdir, makedirs
import argparse
import numpy as np
import glob
from multiprocessing import Pool
from os import path, makedirs
from sklearn.metrics.pairwise import cosine_similarity
import face_alignment
import sys
sys.path.insert(0, '../insightface/deploy/')
import face_model_split
import time
import shutil, json
from tqdm import tqdm
from support_function_0109 import get_file_name, resize_image, prepare_dir, process_image

def add_argumentation(parser):
    parser.add_argument('--folder', '-f', help='image folder')
    parser.add_argument('--savefolder', '-sf', help='image folder')
    parser.add_argument('--thresh', '-th', default=0.75, help='threshold')
    # ArcFace params
    parser.add_argument('--image-size', default='112,112', help='')
    parser.add_argument('--model', help='path to model.',
                        default='../../insightface/models/model-r100-ii/model,0')
    parser.add_argument('--ga-model', default='', help='path to load model.')
    parser.add_argument('--gender_model', default='',
                        help='path to load model.')
    parser.add_argument('--gpu', default=0, type=int, help='gpu id')
    parser.add_argument('--det', default=1, type=int,
                        help='mtcnn: 1 means using R+O, 0 means detect from begining')
    parser.add_argument('--flip', default=0, type=int,
                        help='whether do lr flip aug')
    parser.add_argument('--threshold', default=1.24,
                        type=float, help='ver dist threshold')
    return parser


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Extract features with CNN')
    parser = add_argumentation(parser)
    args = parser.parse_args()
    args.gpu = -1
    args.det = 0
    args.model = ""
    args.thresh = 0.8
    img_heights = [[400]]
    angle_threshs = [19]
    ## load model
    model = face_model_split.FaceModel(args)
    fa = face_alignment.FaceAlignment(face_alignment.LandmarksType._2D, flip_input=False, device='cpu')
    # eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
    savepath = args.savefolder
    savepath, f, f_detail = prepare_dir(savepath, img_heights, angle_threshs)
    filenames = get_file_name(args.folder)
    resize_times = [0]*len(img_heights)*len(angle_threshs)
    rotate_times = [0]*len(img_heights)*len(angle_threshs)
    detection_times = [0]*len(img_heights)*len(angle_threshs)
    processed_count = [0]*len(img_heights)*len(angle_threshs)
    miss = [0]*len(img_heights)*len(angle_threshs)
    subtract = 0
    output = {"filename": "", "image_size": "", "rotate_number":0, "resize_time":0, "rotate_times": 0,
              "detection_times":0,"total_times":0, "missed":"no", "error_type":""}
    for i, filename in enumerate(tqdm(filenames)):
        origin_img = cv2.imread(filename)
        # h,w = origin_img.shape[:2]
        # scale = 12
        # origin_img = origin_img[h//scale:(scale-1)*h//scale, w//scale:(scale-1)*w//scale]
        if origin_img is None:
            print("__skip__")
            subtract = subtract + 1
            continue
        index = 0
        for img_height in img_heights:
            ## resize image
            # img, resize_time = resize_image(origin_img, img_height)
            for angle_thresh in angle_threshs:
                ## process image
                aligned, sum_t, count, rotate_time, error_type, resize_time = process_image(origin_img, img_height, model, fa, float(args.thresh), angle_thresh)
                if index >0:
                    rotate_times[index] += rotate_time
                    resize_times[index] += resize_time
                detection_times[index] += sum_t
                processed_count[index] += count
                output["filename"] = filename
                output["image_size"] = " (" + str(origin_img.shape[0]) + " " + str(origin_img.shape[1]) + ")"
                output["rotate_number"] = count
                output["detection_times"] = sum_t
                output["rotate_times"] = rotate_time
                output["resize_time"] = resize_time
                output["total_times"] = rotate_time + resize_time + sum_t
                output["error_type"] = error_type
                if aligned is None:
                    output["missed"] = "yes"
                    miss[index] += 1
                    f[index].write(filename+"\n")
                f_detail[index].write(json.dumps(output))
                f_detail[index].write("\n")
                if aligned is not None:
                    cv2.imwrite(os.path.join(savepath[index], os.path.basename(filename)), aligned)
                index = index + 1

    for index in range(len(img_heights)*len(angle_threshs)):
        f[index].writelines("--------------------------------------------------\n")
        f[index].writelines("Total images: " + str(len(filenames)-subtract)+"\n")
        f[index].writelines("Total number of rotations: " + str(processed_count[index]) + "\n")
        f[index].writelines("Total rotate times: " + str(rotate_times[index])+"\n")
        f[index].writelines("Total resize times: " + str(resize_times[index]) + "\n")
        f[index].writelines("Total detection times: " + str(detection_times[index]) + "\n")
        t = rotate_times[index] + resize_times[index] + detection_times[index]
        f[index].writelines("Total times processed: " + str(t) + "\n")
        f[index].writelines("Detection time Avg: " + str(detection_times[index] /(len(filenames)-subtract) ) + "\n")
        f[index].writelines("Processed time Avg per image: " + str(t/(len(filenames)-subtract))+"\n")
        f[index].writelines("Missed: " + str(miss[index])+"\n")