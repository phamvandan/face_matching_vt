import numpy as np
a = [[15,6],[8,9]]
b = ["a", "b"]
# a = np.asarray(a)
# print(a[:,0])
zipped = zip(a, b)
t = sorted(zipped, key=lambda x:x[0][0])
# t = np.asarray(t, dtype='float32')
# print(t[:, 0])
print(t)