import cv2
import sys
from  support_function_0109 import rotate, get_file_name, show_img

if __name__ == '__main__':
    filenames = get_file_name(sys.argv[1])
    for index, filename in enumerate(filenames):
        img = cv2.imread(filename)
        # show_img(img)
        rotated = rotate(img, float(sys.argv[2]))
        cv2.imwrite("test_img/"+str(index)+".jpg", rotated)
    print("ok")