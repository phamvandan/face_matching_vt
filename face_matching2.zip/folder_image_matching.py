import  cv2
import sys, argparse, os
import face_alignment
sys.path.insert(0, '../insightface/deploy/')
import face_model_split
from sp_img_to_feature import  process_image, resize_image, show_img
import glob
import numpy as np

def add_argumentation(parser):
    parser.add_argument('--folder', '-f', help='image folder')
    parser.add_argument("--device", "-dv", default="gpu")
    parser.add_argument('--thresh', '-th', default=0.9, help='threshold')
    # ArcFace params
    parser.add_argument('--thresh_score', default=0.5, help='similarity thresh')
    parser.add_argument('--image-size', default='112,112', help='')
    parser.add_argument('--model', help='path to face feature extraction model.',
                        default='./models/arcface_finetune/model,0')
    parser.add_argument('--ga-model', default='', help='path to load model.')
    parser.add_argument('--gender_model', default='',
                        help='path to load model.')
    parser.add_argument('--gpu', default=0, type=int, help='gpu id')
    parser.add_argument('--det', default=0, type=int,
                        help='mtcnn: 1 means using R+O, 0 means detect from begining')
    parser.add_argument('--flip', default=0, type=int,
                        help='whether do lr flip aug')
    parser.add_argument('--threshold', default=1.24,
                        type=float, help='ver dist threshold')
    parser.add_argument('--angle_thresh', default=19,
                        type=float, help='ver dist threshold')
    return parser

def load_model(args):
    if args.device == "cpu":
        args.gpu = -1
        face_model = face_model_split.FaceModel(args)
        fa_model = face_alignment.FaceAlignment(face_alignment.LandmarksType._2D, flip_input=False, device='cpu')
    else:
        face_model = face_model_split.FaceModel(args)
        fa_model = face_alignment.FaceAlignment(face_alignment.LandmarksType._2D, flip_input=False)
    return face_model, fa_model

def read_image_from_folder(folder_name):
    files = glob.glob(folder_name + "/*")
    images = []
    for filename in files:
        img = cv2.imread(filename)
        images.append(img)
    return images

def img_to_feature(img, face_model, fa_model, mode="id"):
    origin_img = img.copy()
    if mode == "id":
        img = resize_img(img, mode)
        aligned_for_process, aligned, detect_time, rotate_number, rotate_time, error_type = process_image(origin_img, img, face_model,fa_model, float( args.thresh), float(args.angle_thresh))
    else:
        img = resize_img(img, mode)
        aligned_for_process, aligned, detect_time, rotate_number, rotate_time, error_type = process_image(origin_img ,img, face_model,fa_model, float( args.thresh), float(args.angle_thresh))
    ## feature extraction
    # show_img(aligned)
    features = face_model.get_feature(aligned_for_process)
    return  features

def resize_img(img, mode):
    if mode == "id":
        img, resize_time = resize_image(img, 800)
    else:
        img, resize_time = resize_image(img, 400)
    return  img

def chisquare(p, q):
    p = np.asarray(p).flatten()
    q = np.asarray(q).flatten()
    bin_dists = (p - q)**2 / (p + q + np.finfo('float').eps)
    return np.sum(bin_dists)

def feature_compare(feature1, feature2):
    dist = np.sum(np.square(feature1- feature2))
    sim = np.dot(feature1, feature2.T)
    return dist, sim

def match(features_a,features_b,METRIC):
    if METRIC == 1:
        _, score = feature_compare(features_a, features_b)
    else:
        score = chisquare(features_a, features_b)
    return score

def demo(document_images, selfie_images, face_model, fa_model, save_path):
    count = 0
    for document_image in document_images:
        feature1 = img_to_feature(document_image, face_model, fa_model, mode="id")
        if feature1 is None:
            cv2.imwrite(os.path.join(save_path, str(count) + "_failure.jpg"), document_image)
            continue
        for selfie_image in selfie_images:
            feature2 = img_to_feature(selfie_image, face_model, fa_model, mode="selfie")
            if feature2 is None:
                cv2.imwrite(os.path.join(save_path, str(count) + "_failure.jpg"), selfie_image)
                continue
            score = match(feature1, feature2, 1)
            print(score)
            document_image = cv2.resize(document_image, (300, 224))
            selfie_image = cv2.resize(selfie_image, (300, 224))
            save_image = np.hstack((document_image, selfie_image))
            cv2.putText(save_image, "Thresh:" + str(args.thresh_score) + "    Similarity:" + str(np.round(score, 2)), (0, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), thickness=2)
            if score > float(args.thresh_score):
                cv2.putText(save_image, "THE SAME PERSON", (0, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0),
                            thickness=2)
                save_dir = os.path.join(save_path, "same")
                if not os.path.exists(save_dir):
                    os.mkdir(save_dir)
                cv2.imwrite(os.path.join(save_dir, str(count) + ".jpg"), save_image)
            else:
                cv2.putText(save_image, "DIFFERENT PERSON", (0, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0),
                            thickness=2)
                save_dir = os.path.join(save_path, "different")
                if not os.path.exists(save_dir):
                    os.mkdir(save_dir)
                cv2.imwrite(os.path.join(save_dir, str(count) + ".jpg"), save_image)
            count = count + 1
    print("End with", count, "image saved")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser = add_argumentation(parser)
    args = parser.parse_args()
    id_path = os.path.join(args.folder, "id")
    selfie_path = os.path.join(args.folder, "selfie")
    save_path = os.path.join(args.folder)
    if not os.path.exists(id_path) or not os.path.exists(selfie_path):
        print("Please insert path")
        raise  EnvironmentError
    document_images = read_image_from_folder(id_path)
    selfie_images = read_image_from_folder(selfie_path)
    ## load model
    count = 0
    face_model, fa_model = load_model(args)
    # read image
    # for document_image in document_images:
    #     feature1 = img_to_feature(document_image, face_model, fa_model)
    #     if feature1 is None:
    #         cv2.imwrite(os.path.join(save_path, str(count) + "_failure.jpg"), document_image)
    #         continue
    #     for selfie_image in selfie_images:
    #         feature2 = img_to_feature(selfie_image, face_model, fa_model)
    #         score = match(feature1, feature2, 2)
    #         print(score)
    demo(document_images, selfie_images, face_model, fa_model, save_path)

