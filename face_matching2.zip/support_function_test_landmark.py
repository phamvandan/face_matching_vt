import cv2, os, time, imutils, shutil, math
import numpy as np
import sys


# Disable
def blockPrint():
    sys.stdout = open(os.devnull, 'w')


# Restore
def enablePrint():
    sys.stdout = sys.__stdout__


''' rotate image with any angle '''


def rotate(mat, angle):
    if angle == 0:
        return mat
    height, width = mat.shape[:2]
    image_center = (width / 2, height / 2)
    rotation_mat = cv2.getRotationMatrix2D(image_center, angle, 1.)
    abs_cos = abs(rotation_mat[0, 0])
    abs_sin = abs(rotation_mat[0, 1])
    bound_w = int(height * abs_sin + width * abs_cos)
    bound_h = int(height * abs_cos + width * abs_sin)
    rotation_mat[0, 2] += bound_w / 2 - image_center[0]
    rotation_mat[1, 2] += bound_h / 2 - image_center[1]
    rotated_mat = cv2.warpAffine(mat, rotation_mat, (bound_w, bound_h))
    return rotated_mat


'''Get all files name from folder'''


def get_file_name(folder):
    filenames = []
    for path, subdirs, files in os.walk(folder):
        for name in files:
            filename = os.path.join(path, name)
            filenames.append(filename)
    return filenames


'''Resize image with option'''


def resize_image(img, img_height):
    start = time.time()
    temp = img.copy()
    # if img_height == -2:
    #     if img.shape[0] < 800:
    #         temp = imutils.resize(temp, height=800)
    #     elif img.shape[1] < 800:
    #         temp = imutils.resize(temp, width=800)
    #     end = time.time()
    #     return temp, end - start
    # if img_height >0 and img.shape[0] < img_height:
    #     temp = imutils.resize(temp, height=img_height)
    # end = time.time()
    ## origin image
    if img_height != -1:
        temp = imutils.resize(temp, height=img_height)
    return temp, time.time() - start


'''Prepare directory'''


def prepare_dir(savepath, img_heights, angle_threshs):
    if os.path.exists(savepath):
        shutil.rmtree(savepath)
    os.mkdir(savepath)
    savepath2 = []
    f = []
    f_detail = []
    for img_height in img_heights:
        root = os.path.join(savepath, str(img_height))
        os.mkdir(root)
        for angle_thresh in angle_threshs:
            temp = os.path.join(root, str(angle_thresh))
            os.mkdir(temp)
            savepath2.append(temp)
            f1 = open(os.path.join(temp, "result.txt"), "w+")
            f_detail1 = open(os.path.join(temp, "details.txt"), "w+")
            f.append(f1)
            f_detail.append(f_detail1)
    return savepath2, f, f_detail


def get_boxes(bboxs, thresh):
    detected_faces = []
    for bbox in bboxs:
        x, y, a, b, confidence = bbox
        if confidence < thresh:
            break
        detected_faces.append(bbox)
    detected_faces = sorted(detected_faces, key=lambda x: x[4], reverse=True)
    return detected_faces


def euclid_distace(a, b):
    x, y = a
    k, h = b
    return math.sqrt((x - k) ** 2 + (h - y) ** 2)


def mean_cal(idxs, landmarks):
    x = 0
    y = 0
    for idx in idxs:
        x = x + landmarks[idx][0]
        y = y + landmarks[idx][1]
    return np.asarray([x // len(idxs), y // len(idxs)])


def add_point(a, b):
    x1, y1 = a
    x2, y2 = b
    return (x1 + x2, y1 + y2)


def med_point(a, b):
    x1, y1 = a
    x2, y2 = b
    return (x1 + x2) / 2, (y1 + y2) / 2


def get_angle(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    if y1==y2:
        if x1 < x2:
            return 0
        else:
            return 180
    if x1==x2:
        if y2>y1:
            return  90
        else:
            return 270
    angle = math.degrees(math.atan(abs(y2 - y1) / abs(x2 - x1)))
    if x1<x2:
        if y1 < y2:
            return angle
        else:
            return 360 - angle
    if x1 > x2:
        if y1 < y2:
            return  180 - angle
        else:
            return  180 + angle

def check_true_landmark(points):
    # blockPrint()
    delta = 4
    d1 = euclid_distace(points[0], points[4])
    d10 = euclid_distace(points[0], points[2])
    d11 = euclid_distace(points[4], points[2])
    if d10 + d11 - d1 > delta:
        print("lech tam 0 4")
        return False

    d2 = euclid_distace(points[1], points[3])
    d20 = euclid_distace(points[1], points[2])
    d21 = euclid_distace(points[3], points[2])

    if d20 + d21 - d2 > delta:
        print("lech tam 1 3")
        return False

    ## khoang cach 2 mat > khoang cach mieng
    if euclid_distace(points[0], points[1]) <= euclid_distace(points[3], points[4]):
        print("khoang cach 2 mat < khoang cach mieng")
        return False

    if d1 < delta or d2 < delta:
        print("mat or mieng qua be")
        return False

    a, b = add_point(points[0], points[1])
    x, y = add_point(points[3], points[4])
    if b >= y:
        print("Mat tren mieng")
        return False

    delta_nose = 6
    if abs(euclid_distace(points[0], points[2]) - euclid_distace(points[1], points[2])) >= delta_nose:
        print("Mat mui lech")
        return False
    delta_mouth = 4
    if abs(abs(
            euclid_distace(points[3], points[2]) - euclid_distace(points[4], points[2])) >= delta_mouth):
        print("Mieng mui lech")
        return False
    return True


def check_true_landmark_v2(points, angle_thr = 13):
    error = "Landmark true"
    blockPrint()
    ## mat lech
    delta = 4
    d1 = euclid_distace(points[0], points[4])
    d2 = euclid_distace(points[1], points[3])
    # d3 = euclid_distace(points[0], points[2])
    # d4 = euclid_distace(points[3], points[2])
    # print(d1, d2, d3, d4)
    ## khoang cach 2 mat > khoang cach mieng
    if euclid_distace(points[0], points[1]) <= euclid_distace(points[3], points[4]):
        error = "khoang cach 2 mat < khoang cach mieng"
        print("khoang cach 2 mat < khoang cach mieng")
        return False, error
    ## mat mieng qua be
    if d1 < delta or d2 < delta:
        error = "mat or mieng qua be " + str(d1) + " " + str(d2)
        print("mat or mieng qua be")
        return False, error
    # ## cam nam duoi
    # chin_idx = np.argmin(landmark[:, 1])
    # print("chin_idx", chin_idx)
    # if not ((chin_idx>=0 and chin_idx<=3) or (chin_idx>=13 and chin_idx<=26)):
    #     print("landmark lon xon")
    #     return False
    # angle = abs(get_angle(points[2],landmark[8]) - get_angle(points[3], points[4]))
    angle_eye = get_angle(points[0], points[1])
    print("angle eye=", angle_eye)
    angle_nose = get_angle(med_point(points[0], points[1]), points[2])
    print("angle nose=", angle_nose)
    angle = abs(angle_eye - angle_nose)
    print(angle)
    if not(abs(angle - 90) <= angle_thr or abs(angle - 270) <= angle_thr):
        error = "error angle eye nose " + str(angle)
        print("error angle eye nose")
        return False, error

    angle_mouth = get_angle(points[3], points[4])
    print("angle_mouth", angle_mouth)
    angle_nose = get_angle(points[2], med_point(points[3], points[4]))
    print("angle_nose", angle_nose)
    angle = abs(angle_mouth - angle_nose)
    print(angle)
    if not(abs(angle - 90) <= angle_thr or abs(angle - 270) <= angle_thr):
        error = "error angle mouth nose " + str(angle)
        print("error angle mouth nose")
        return False, error
    angle = abs(angle_eye - angle_mouth)
    
    dt = 1.25
    if not (angle <= angle_thr//dt or abs(360 - angle) <= angle_thr//dt):
        error = "error angle mouth eye " + str(angle)
        print("error angle mouth eye")
        return False, error
    return True, error


def normalize_landmark(landmark):
    LEFT_EYE = [36, 37, 38, 39, 40, 41]
    RIGHT_EYE = [42, 43, 44, 45, 46, 47]
    NOSE = [29, 30]
    LEFT_MOUTH = [48, 49, 59]
    RIGHT_MOUTH = [53, 54, 55]
    points = np.zeros((5, 2))
    points[0] = mean_cal(LEFT_EYE, landmark)
    points[1] = mean_cal(RIGHT_EYE, landmark)
    points[2] = mean_cal(NOSE, landmark)
    points[3] = mean_cal(LEFT_MOUTH, landmark)
    points[4] = mean_cal(RIGHT_MOUTH, landmark)
    return points


def show_img(img, name="ok"):
    cv2.imshow(name, img)
    cv2.waitKey(0)


def draw_points(face_img, points):
    for point in points:
        a, b = point
        a = int(a)
        b = int(b)
        cv2.circle(face_img, (a, b), 3, (0, 255, 0), -1)
    # face_img = imutils.resize(face_img, height=500)
    show_img(face_img)


def process_not_detect(face_img, model, fa_model, debug=True, threshold=0.7, angle_thresh=13):
    start = time.time()
    temp = None
    aligned = None
    detected_faces = []
    detected_faces.append([0, 0, face_img.shape[1], face_img.shape[0]])
    if len(detected_faces) > 0:
        detected_faces = np.asarray(detected_faces)
        landmarks = fa_model.get_landmarks(face_img, detected_faces)
        for index, landmark in enumerate(landmarks):
            if debug:
                draw_points(face_img.copy(), landmark)
            points = normalize_landmark(landmark)
            if debug:
                draw_points(face_img.copy(), points)
            ret, error = check_true_landmark_v2(points, angle_thr=angle_thresh)
            if not ret:
                continue
            aligned, temp = model.aligned_face(face_img, detected_faces[index], points)
            if debug:
                show_img(temp)
            break
    return aligned, temp, time.time() - start, error

def draw_rect(img, detected_face):
    x,y,a,b,_ = detected_face
    x = int(x)
    y = int(y)
    a = int(a)
    b = int(b)
    print("face shape", (int(a-x), int(b-y)))
    cv2.rectangle(img, (x,y), (a,b), (0,255,255),2)
    show_img(img)


def get_landmarks(face_img, fa_model, detected_face,angle_thresh, debug=True):
    start = time.time()
    landmark = fa_model.get_landmarks(face_img, detected_face)
    print("t = ", time.time() - start)
    draw_rect(face_img.copy(), detected_face)
    if debug:
        draw_points(face_img.copy(), landmark)
        # show_img(face_img.copy())
    points = normalize_landmark(landmark)
    if debug:
        draw_points(face_img.copy(), points)
    ret, error = check_true_landmark_v2(points, angle_thr=angle_thresh)
    enablePrint()
    return ret, error, points

def process(origin_img, face_img, model, fa_model, debug=False, threshold=0.7, angle_thresh=13):
    enablePrint()
    error = "No face"
    ori_h, ori_w = origin_img.shape[:2]
    print("ss",origin_img.shape[:2])
    h, w = face_img.shape[:2]
    print("ssss",face_img.shape[:2])
    start = time.time()
    ret = model.detect_faces(face_img)
    if ret is None:
        return None, None, time.time() - start, error
    bboxs, points = ret
    if bboxs.shape[0] == 0:
        return None, None, time.time() - start, error
    temp = None
    aligned = None
    detected_faces = get_boxes(bboxs, threshold)
    if len(detected_faces) > 0:
        for detected_face in detected_faces:
            ret, error, points = get_landmarks(face_img, fa_model, detected_face, angle_thresh)
            if ret:
                aligned, temp = model.aligned_face(face_img, detected_face, points)
                show_img(temp, "small")
            detected_face[0] = detected_face[0]*ori_w/w
            detected_face[1] = detected_face[1]*ori_h/h
            detected_face[2] = detected_face[2]*ori_w/w
            detected_face[3] = detected_face[3]*ori_h/h
            print("origin image")
            ret, error, points = get_landmarks(origin_img, fa_model, detected_face, angle_thresh)
            if ret:
                aligned, temp = model.aligned_face(origin_img, detected_face, points)
                show_img(temp, "origin")
            # break
    else:
        error = "Below threshold "
    return aligned, temp, time.time() - start, error


'''Main processing image'''


def process_image(origin_img, img, model, fa_model, thresh, angle_thresh):
    sum_t = 0  ## total time to process
    count = 0  ## number of time to process
    rotate_time = 0
    aligned = None
    error_type1 = ""
    for i in range(4):
        start = time.time()
        temp = rotate(img, 90 * i)
        temp_ori = rotate(origin_img, 90 * i)
        end = time.time()
        if i > 0:
            rotate_time = rotate_time + end - start
            count = count + 1
        # _, aligned, t, error_type = process_not_detect(temp, model, fa_model, threshold=thresh, debug=True)
        # error_type = ""
        _, aligned, t, error_type = process(temp_ori, temp, model, fa_model,angle_thresh=angle_thresh, threshold=thresh, debug=True)
        error_type1 = error_type1 + "|" + error_type
        # _, aligned, t = process_not_detect(temp, model, fa_model, debug=True)
        sum_t = sum_t + t
        if aligned is not None:
            break
    return aligned, sum_t, count, rotate_time, error_type1
