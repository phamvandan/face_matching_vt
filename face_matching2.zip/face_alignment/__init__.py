# -*- coding: utf-8 -*-

__author__ = """Adrian Bulat"""
__email__ = 'adrian.bulat@nottingham.ac.uk'
__version__ = '1.1.0'

from .api import FaceAlignment, LandmarksType, NetworkSize
