import cv2
import sys, argparse, os
import face_alignment

sys.path.insert(0, '../insightface/deploy/')
import face_model_split
from sp_img_to_feature import process_image, resize_image, show_img
import configparser
import json

class argument:
    def __init__(self, config):
        self.image_size = '112,112'
        self.gpu = 0
        # if config["DEVICE"]["MODE"] == "cpu":
        #     print("using cpu")
        #     self.gpu = -1
        self.device = config["DEVICE"]["MODE"]
        self.model = config["PATH"]["MODEL"]
        self.ga_model = ""
        self.gender_model = ""
        self.det = int(config["DETECT"]["MODE"])
        self.flip = 0
        self.threshold = 1.24
        self.angle_thresh = float(config["DETECT"]["ANGLE_THRESH"])
        self.mode = config["TASK"]["MODE"]
        self.path_image = config["PATH"]["IMAGE"]
        if self.mode == "id":
            self.thresh = float(config["DETECT"]["ID_THRESH"])
            print(self.thresh)
        else:
            self.thresh = float(config["DETECT"]["SF_THRESH"])


def add_argumentation(parser):
    parser.add_argument("--path_image", "-p")
    parser.add_argument("--mode", "-m", default='id')
    parser.add_argument("--device", "-dv", default="gpu")
    parser.add_argument('--thresh', '-th', default=0.9, help='threshold')
    # ArcFace params
    parser.add_argument('--image-size', default='112,112', help='')
    parser.add_argument('--model', help='path to face feature extraction model.',
                        default='./models/arcface_finetune/model,0')
    parser.add_argument('--ga-model', default='', help='path to load model.')
    parser.add_argument('--gender_model', default='',
                        help='path to load model.')
    parser.add_argument('--gpu', default=0, type=int, help='gpu id')
    parser.add_argument('--det', default=0, type=int,
                        help='mtcnn: 1 means using R+O, 0 means detect from begining')
    parser.add_argument('--flip', default=0, type=int,
                        help='whether do lr flip aug')
    parser.add_argument('--threshold', default=1.24,
                        type=float, help='ver dist threshold')
    parser.add_argument('--angle_thresh', default=19,
                        type=float, help='ver dist threshold')
    return parser


def load_model(args):
    if args.device == "cpu":
        args.gpu = -1
        face_model = face_model_split.FaceModel(args)
        fa_model = face_alignment.FaceAlignment(face_alignment.LandmarksType._2D, flip_input=False, device='cpu')
    else:
        face_model = face_model_split.FaceModel(args)
        fa_model = face_alignment.FaceAlignment(face_alignment.LandmarksType._2D, flip_input=False)
    return face_model, fa_model


if __name__ == '__main__':
    # parser = argparse.ArgumentParser()
    # parser = add_argumentation(parser)
    # args = parser.parse_args()
    config = configparser.ConfigParser()
    config.read("img_to_feature.cfg")
    args = argument(config)
    # read image
    # if not os.path.isfile(args.path_image):
    #     print("Please insert path to image")
    #     raise FileNotFoundError
    ori_img = cv2.imread(args.path_image)

    ## load model
    face_model, fa_model = load_model(args)

    ## resize image
    img_heights = None
    if config["TASK"]["MODE"] == "id":
        img_heights = json.loads(config["SIZE"]["ID_HEIGHTS"])
    else:
        img_heights = json.loads(config["SIZE"]["SF_HEIGHTS"])
    print(img_heights)
    print(type(img_heights))
    ## detect and aligned face
    aligned_for_process, aligned, detect_time, rotate_number, rotate_time, error_type, resize_times = process_image(
        ori_img, img_heights, face_model, fa_model, float(args.thresh), float(args.angle_thresh))
    print(error_type)
    if aligned is not None:
        ## feature extraction
        show_img(aligned)
        features = face_model.get_feature(aligned_for_process)
